`timescale 1ns/1ps

module tb_systolic_array;

parameter N = 4;

reg clk;
reg rst;

reg signed [7:0] A [0:N-1][0:N-1];
reg signed [7:0] B [0:N-1][0:N-1];

wire signed [31:0] C [0:N-1][0:N-1];

integer i,j;

//////////////////////////////////////////////////////
// DUT
//////////////////////////////////////////////////////

systolic_array_4x4_pro dut(
    .clk(clk),
    .rst(rst)
);

//////////////////////////////////////////////////////
// Clock
//////////////////////////////////////////////////////

always #5 clk = ~clk;

//////////////////////////////////////////////////////
// Load Matrix A
//////////////////////////////////////////////////////

task load_matrix_A;
    integer file, r;
    begin
        file = $fopen("data/matrix_a_dense.txt","r");

        for(i=0;i<N;i=i+1)
        begin
            for(j=0;j<N;j=j+1)
            begin
                r = $fscanf(file,"%d",A[i][j]);
            end
        end

        $fclose(file);
        $display("Matrix A Loaded");
    end
endtask

//////////////////////////////////////////////////////
// Load Matrix B
//////////////////////////////////////////////////////

task load_matrix_B;
    integer file, r;
    begin
        file = $fopen("data/matrix_b_dense.txt","r");

        for(i=0;i<N;i=i+1)
        begin
            for(j=0;j<N;j=j+1)
            begin
                r = $fscanf(file,"%d",B[i][j]);
            end
        end

        $fclose(file);
        $display("Matrix B Loaded");
    end
endtask

//////////////////////////////////////////////////////
// Display Result
//////////////////////////////////////////////////////

task print_result;
    begin
        $display("Result Matrix C:");

        for(i=0;i<N;i=i+1)
        begin
            for(j=0;j<N;j=j+1)
            begin
                $write("%d ",C[i][j]);
            end
            $display("");
        end
    end
endtask

//////////////////////////////////////////////////////
// Test Sequence
//////////////////////////////////////////////////////

initial
begin
 
    $dumpfile("waves/systolic.vcd");
    $dumpvars(0,tb_systolic_array);


    clk = 0;
    rst = 1;

    #20
    rst = 0;

    load_matrix_A();
    load_matrix_B();

    #200

    print_result();

    $finish;

end

endmodule
