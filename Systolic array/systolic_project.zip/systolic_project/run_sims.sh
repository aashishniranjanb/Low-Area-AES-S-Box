#!/bin/bash

echo "====================================="
echo " RUNNING DENSE DATASET (0% Sparsity)"
echo "====================================="
cp scripts/matrix_A_dense.txt data/A_test.txt
cp scripts/matrix_B_dense.txt data/B_test.txt
cp scripts/matrix_C_dense.txt data/C_test.txt

ncverilog +access+r rtl/*.v tb/tb_power_compare.v 
mv waves/current_run.vcd waves/dense.vcd

echo "====================================="
echo " RUNNING SPARSE DATASET (70% Sparsity)"
echo "====================================="
cp scripts/matrix_A_sparse.txt data/A_test.txt
cp scripts/matrix_B_sparse.txt data/B_test.txt
cp scripts/matrix_C_sparse.txt data/C_test.txt

ncverilog +access+r rtl/*.v tb/tb_power_compare.v 
mv waves/current_run.vcd waves/sparse.vcd

echo "====================================="
echo " RUNNING VERY SPARSE DATASET (90% Sparsity)"
echo "====================================="
cp scripts/matrix_A_very_sparse.txt data/A_test.txt
cp scripts/matrix_B_very_sparse.txt data/B_test.txt
cp scripts/matrix_C_very_sparse.txt data/C_test.txt

ncverilog +access+r rtl/*.v tb/tb_power_compare.v 
mv waves/current_run.vcd waves/very_sparse.vcd

echo "====================================="
echo " ALL SIMULATIONS COMPLETE!"
echo " VCD files are saved in the waves/ directory."
echo "====================================="
