add_search_path . /home/install/GENUS211/tools.lnx86/lib/tech -library -both
read_library -liberty -both \
    /home/install/IC618/RA2311067010024/FOUNDRY/digital/45nm/NangateOpenCellLibrary_v1.00_20080225/liberty/FreePDK45_lib_v1.0_typical.lib \
    /home/install/IC618/RA2311067010024/FOUNDRY/digital/45nm/NangateOpenCellLibrary_v1.00_20080225/liberty/FreePDK45_lib_v1.0_typical.lib

