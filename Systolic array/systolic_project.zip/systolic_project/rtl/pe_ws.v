`timescale 1ns/1ps
`default_nettype none

module pe_ws #(
    parameter DATA_WIDTH = 8,
    parameter ACC_WIDTH  = 32
)(
    input  wire                         clk,
    input  wire                         rst,

    /* control */
    input  wire                         weight_load,
    input  wire                         acc_clear,
    input  wire                         valid_in,

    /* data inputs */
    input  wire signed [DATA_WIDTH-1:0] activation_in,
    input  wire signed [DATA_WIDTH-1:0] weight_in,
    input  wire signed [ACC_WIDTH-1:0]  psum_in,

    /* data outputs */
    output reg  signed [DATA_WIDTH-1:0] activation_out,
    output reg  signed [ACC_WIDTH-1:0]  psum_out,

    /* pipeline control */
    output reg                          valid_out
);

    /* 1. Weight Register */
    reg signed [DATA_WIDTH-1:0] weight_reg;
    always @(posedge clk) begin
        if (rst) weight_reg <= 0;
        else if (weight_load) weight_reg <= weight_in;
    end

    /* 2. Input-Hold Operand Isolation */
    wire is_zero = (activation_in == 0) || (weight_reg == 0);
    wire skip = !valid_in || is_zero;

    reg signed [DATA_WIDTH-1:0] mult_a_reg;
    reg signed [DATA_WIDTH-1:0] mult_b_reg;
    reg                         mult_en_reg;

    reg signed [DATA_WIDTH-1:0] act_in_pipe;
    reg signed [ACC_WIDTH-1:0]  psum_in_pipe;
    reg                         valid_in_pipe;

    always @(posedge clk) begin
        if (rst) begin
            mult_a_reg    <= 0;
            mult_b_reg    <= 0;
            mult_en_reg   <= 0;
            act_in_pipe   <= 0;
            psum_in_pipe  <= 0;
            valid_in_pipe <= 0;
        end else begin
            act_in_pipe   <= activation_in;
            psum_in_pipe  <= psum_in;
            valid_in_pipe <= valid_in;

            if (!skip) begin
                mult_a_reg  <= activation_in;
                mult_b_reg  <= weight_reg;
                mult_en_reg <= 1'b1;
            end else begin
                // Lock the inputs! This stops dynamic power switching.
                mult_a_reg  <= mult_a_reg;
                mult_b_reg  <= mult_b_reg;
                mult_en_reg <= 1'b0;
            end
        end
    end

    /* 3. Multiplier & Pipeline */
    wire signed [ACC_WIDTH-1:0] mult_result_w = mult_a_reg * mult_b_reg;

    reg signed [ACC_WIDTH-1:0] pipe_mult_reg;
    reg signed [ACC_WIDTH-1:0] pipe_psum_reg;
    reg pipe_valid_reg;

    always @(posedge clk) begin
        if (rst) begin
            pipe_mult_reg  <= 0;
            pipe_psum_reg  <= 0;
            pipe_valid_reg <= 0;
        end else begin
            pipe_mult_reg  <= mult_result_w;
            pipe_psum_reg  <= psum_in_pipe; 
            pipe_valid_reg <= valid_in_pipe & mult_en_reg;
        end
    end

    /* 4. Accumulator */
    reg signed [ACC_WIDTH-1:0] acc_reg;

    always @(posedge clk) begin
        if (rst) begin
            acc_reg        <= 0;
            activation_out <= 0;
            psum_out       <= 0;
            valid_out      <= 0;
        end else begin
            if (acc_clear) begin
                acc_reg <= 0;
            end else if (pipe_valid_reg) begin
                acc_reg <= pipe_psum_reg + pipe_mult_reg;
            end
            
            activation_out <= act_in_pipe; 
            psum_out       <= acc_reg;
            valid_out      <= valid_in_pipe;
        end
    end
endmodule
`default_nettype wire
