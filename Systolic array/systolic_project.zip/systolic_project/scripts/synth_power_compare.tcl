set PROJECT_DIR /home/install/IC618/RA2311067010024/systolic_project
set RTL_DIR      $PROJECT_DIR/rtl
set REPORT_DIR   $PROJECT_DIR/reports
set LIB_PATH /home/install/IC618/RA2311067010024/FOUNDRY/digital/45nm/NangateOpenCellLibrary_v1.00_20080225/liberty/FreePDK45_lib_v1.0_typical.lib

read_libs $LIB_PATH
read_hdl $RTL_DIR/pe_ws.v
read_hdl $RTL_DIR/localized_controller.v
read_hdl $RTL_DIR/systolic_array_4x4.v

elaborate systolic_array_4x4

# Constraints
create_clock -name clk -period 10 [get_ports clk]
set_input_delay  2 -clock clk [all_inputs -no_clocks]
set_output_delay 2 -clock clk [all_outputs]
set_operating_conditions -library typical

# Synthesis Mapping
set_db syn_global_effort high
set_db syn_map_effort high
syn_generic
syn_map
syn_opt

# =========================================================
# THE 3-WAY POWER ANALYSIS
# =========================================================

# 1. DENSE POWER (Baseline)
puts "Analyzing Dense Workload..."
read_vcd -vcd_module tb_power_compare/dut -static $PROJECT_DIR/waves/dense.vcd
report_power > $REPORT_DIR/power_1_dense.rpt

# 2. SPARSE POWER (70%)
puts "Analyzing Sparse Workload (70%)..."
read_vcd -vcd_module tb_power_compare/dut -static $PROJECT_DIR/waves/sparse.vcd
report_power > $REPORT_DIR/power_2_sparse.rpt

# 3. VERY SPARSE POWER (90%)
puts "Analyzing Very Sparse Workload (90%)..."
read_vcd -vcd_module tb_power_compare/dut -static $PROJECT_DIR/waves/very_sparse.vcd
report_power > $REPORT_DIR/power_3_verysparse.rpt

report_area > $REPORT_DIR/final_area.rpt
report_timing > $REPORT_DIR/final_timing.rpt

puts "------------------------------------------"
puts "3-WAY POWER ANALYSIS COMPLETE!"
puts "Check power_1, power_2, and power_3 reports."
puts "------------------------------------------"
exit
