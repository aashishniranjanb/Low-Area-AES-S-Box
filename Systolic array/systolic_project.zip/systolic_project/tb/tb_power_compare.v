`timescale 1ns/1ps
module tb_power_compare;
    reg clk=0, rst, start;
    always #5 clk = ~clk;
    reg signed [31:0] act_bus, wt_bus;
    wire signed [127:0] res_bus;
    wire done;
    systolic_array_4x4 dut (.clk(clk), .rst(rst), .start(start), .activation_in(act_bus), .weight_in(wt_bus), .result_out(res_bus), .done(done));
    reg signed [7:0] a[0:15], w[0:15]; reg signed [31:0] g[0:15];
    integer fA, fB, fC, r, i;
    initial begin
        $dumpfile("waves/current_run.vcd"); $dumpvars(0, tb_power_compare);
        fA = $fopen("data/matrix_A_very_sparse.txt", "r");
        fB = $fopen("data/matrix_B_very_sparse.txt", "r");
        fC = $fopen("data/matrix_C_very_sparse.txt", "r");
        for (i=0; i<16; i=i+1) begin r=$fscanf(fA,"%d",a[i]); r=$fscanf(fB,"%d",w[i]); r=$fscanf(fC,"%d",g[i]); end
        rst=1; start=0; #20 rst=0;
        act_bus = {a[3], a[2], a[1], a[0]}; wt_bus = {w[3], w[2], w[1], w[0]};
        #10 start=1; #10 start=0; wait(done); #100; $finish;
    end
endmodule
